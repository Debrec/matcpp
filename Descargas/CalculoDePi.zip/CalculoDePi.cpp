#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdio>
#include <string>
#include <cstring>
#include <cstdlib>

using namespace std;

class SumasParciales {
public:
  double factorial (double Num) {
    if (Num > 1) {
      return Num * factorial(Num-1);
    } else if (Num == 1) {
      return 1;
    } else {
      return -1;
    }
  }

  virtual double termino(double x,int i) {}

  double suma_parcial(double x,int Num) {
    double var=0;
    for (int i=0; i<Num; i++) {
      var = var + termino(x,i);
    }
    return var;
  }
};


class Mat : public SumasParciales {
public:
  int num;
  Mat *fun;
  Mat *dfundx;

  virtual void init(int n) {};
  virtual void finish() {};

};

class CalculoDePi : public Mat {
public:
  double termino(double x,int i) {
    return pow(-1.0,i)/(2*i+1);
  }
};

double calculo_de_pi(int Num) {
  Mat *CalcPi = new CalculoDePi;

  return (4 * CalcPi->suma_parcial(0,Num));
}

double error_calculo_pi(int Num) {
  double error = 1/double(2*Num+1);
  return error;
}

void calculo_pi_interface () {
  int Nro=0;
  string sNro;
  do {
    cout << "Presionar s para salir"<<endl;
    cout << "Introducir el Numero de iteraciones : ";
    getline(cin,sNro);
    cout << endl;
    cout << endl;
    char *cNro;
    cNro = new char [int(sNro.size())];
    strcpy(cNro,(const char *)(sNro.c_str()));
    if (  Nro = atoi(cNro)) {
      double pi=0;
      double err=-1;
      pi = calculo_de_pi(Nro);
      err = error_calculo_pi(Nro);

      if (pi != 0) {
        cout << "Pi : ";

        cout << setprecision(10) << fixed << pi;
        cout << "  Error Apróximado : ";
        cout << setprecision(10) << fixed << err ;
        cout << endl;
        cout << endl;
        cout << "Calculo Completado" << endl;
      }
      cout << endl;
    } else if (!strcmp(cNro,"s")) {
      cout << "Dejando el programa" << endl;
      break;
    } else {
      cout << "Error los caracteres ingresados" << endl;
      cout << "no corresponden a un número enteró;" << endl;
      cout << endl;
    }
    delete [] cNro;
  } while(true);
}

int main(int argc,char **argv) {
  calculo_pi_interface();
}
