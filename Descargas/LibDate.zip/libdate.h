//Subrutinas para contar numero de horas desde una fecha de referencia,
//Hasta la hora actual
//Todav�a se encuentran en desarrollo.
//Autor: Hern�n H. G. Braile
//Email: hgbraile@yahoo.com.ar
//Last Change: 14-11-2006

#include <fstream>
#include <iostream>
#include <cmath>

//////////////////////****  jhy  ****/////////////////////////////
//En todos los casos iyear corresponde al indice del array que almacena
//los a�os en secuencias de 1, usualmente
//El a�o se calcula sumando 1900 a iyear. A�o=1900+iyear
int leap(int year);//Devuelve 1 si ela�o es biciesto 0 en cualquier otro caso
int countyear(int iyear0,int iyear1);
int countmonth(int iyear0,int imonth0,int imonth1);
int countday(int iyear0,int imonth0,int iday0,int iday1);
//devuelve dada la fecha la cantidad de horas desde la fecha de,
//referencia
int jhy(int iyear1,int imonth1,int iday1);

//int bisn(int ni,int nf,float fun(float),int nj);
int bisnyear(int ni,int nf,int nj);
int bisnmonth(int ni,int nf,int nj,int iyear1);
int bisnday(int ni,int nf,int nj,int iyear1,int imonth1);
//Devuelve dada la cantidad de horas desde el a�o de referencia,
//la fecha actual
int bisnt(int jhym,int &year,int &month,int &day);

//////////////////////****  jhd  ****/////////////////////////////
float jhd(int hour,int min,int sec);
void bisnhd(float jhd1,int &hour,int &min,int &sec);
