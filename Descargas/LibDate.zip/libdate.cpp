//Subrutinas para contar numero de horas desde una fecha de referencia,
//Hasta la hora actual
//Todav�a se encuentran en desarrollo.
//Autor: Hern�n H. G. Braile
//Email: hgbraile@yahoo.com.ar
//Last Change: 14-11-2006

#include <fstream>
#include <iostream>
#include <cmath>
#include "libdate.h"

using namespace std;

//Devuelve 0 si el a�o es biciesto y 1 en cualquier otro caso.
int leap(int year)
{
    int lpy=0;
    if(year/1000.==int(year/1000.)){
           if(year/400.==int(year/400.))lpy=1;
           }
    else if(year/100.==int(year/100.)){
            if(year/40.==int(year/40.))lpy=1;
            }
    else{
       if(year/4.==int(year/4.))lpy=1;
       }
       
    return(lpy);
}

//Calcula el numero de horas desde el a�o con indice iyear0 hasta el
//a�o con indice iyear1, donde iyear0, iyear1 son los indices de un 
//array bidimensional.
int countyear(int iyear0,int iyear1)
{
    int Ndm[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    int year,month,day,hour;
    int count=0;
    //int iyear[201],leap[201];
      
    /*ifstream in("leapyear.txt");
    for(int i=0;i<201;i++)in>>iyear[i]>>leap[i];*/
    
    for(int i=iyear0;i<iyear1;i++){

      for(day=1;day<=31;day++)//Enero 
      for(hour=0;hour<24;hour++)
      count++;
        
      for(day=1;day<=28+leap(i);day++)//febrero
      for(hour=0;hour<24;hour++)
      count++; 
      
      for(month=2;month<12;month++){
      for(day=1;day<=Ndm[month];day++)
      for(hour=0;hour<24;hour++)
      count++;
      }
  }
return(count);
}

//Numero de horas desde imonth0 hasta imonth1
//Para el a�o iyear0
int countmonth(int iyear0,int imonth0,int imonth1)
{
    int Ndm[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    int year,month,day,hour;
    int count=0;
    int i;//,iyear[201],leap[201];
    
    /*ifstream in("leapyear.txt");
    for(int i=0;i<201;i++)in>>iyear[i]>>leap[i];*/
    
    i=iyear0;
    if(imonth0>imonth1){cout<<"Error de argumentos"<<endl;
                        cout<<"imonth1 debe ser mayor a imonth0"<<endl;    
                        exit(0);}
                        
    if(imonth0==1){  
      for(day=1;day<31;day++)//Enero 
      for(hour=0;hour<24;hour++)
      count++;
      }
    if(imonth0<=2&&imonth1>2){  
      for(day=1;day<28+leap(i);day++)//febrero
      for(hour=0;hour<24;hour++)
      count++; 
      }
    if(imonth1>3){  
      for(month=3;month<imonth1;month++)
      for(day=1;day<Ndm[month];day++)
      for(hour=0;hour<24;hour++)
      count++;
      }
      
return(count);
}

//Numero de horas entre iday0 e iday1
int countday(int iyear0,int imonth0,int iday0,int iday1)
{
    int Ndm[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    int year,month,day,hour;
    int count=0;
    int i;//,iyear[201],leap[201];
    
   /* ifstream in("leapyear.txt");
    for(int i=0;i<201;i++)in>>iyear[i]>>leap[i];*/
    
    i=iyear0;
    if(iday0>iday1){cout<<"Error de argumentos"<<endl;
                        cout<<"iday1 debe ser mayor a iday0 "<<endl;    
                        exit(0);}
                        
    if(imonth0==2){  
        if(iday1>28+leap(i)){/*cout<<"Error iday debe ser menor a "<<
                              28+leap[i]<<endl;*/ return(-1);} 
    }
    else{  
      month=imonth0;
      if(iday1>Ndm[month]){/*cout<<"Error iday debe ser menor a "<<
                              Ndm[month]<<endl;*/ return(-1);} 
    }
    for(day=iday0;day<iday1;day++)
    for(hour=0;hour<24;hour++)
    count++;
     
return(count);
}

int jhy(int iyear1,int imonth1,int iday1)
{
    int jm;
    
    jm=countyear(1900,iyear1);
    jm=countmonth(iyear1,1,imonth1)+jm;
    jm=countday(iyear1,imonth1,1,iday1)+jm; 
    
  return(jm);
}    

int bisnyear(int ni,int nf,int nj)
{
     float a,b,jm,err=2,fa,fb,fc;
     a=float(ni); b=float(nf); jm=float(nj);
     float c;

     while(err>1){
                   fa=countyear(1900,int(a)); fb=countyear(1900,int(b));    
                   c=(a+b)/2;
                   fc=countyear(1900,int(c));
                   if(jm==fb){c=b;err=0;}
                   else if(jm==fa){c=a;err=0;} 
                   else if(jm>fc&&jm<fb){a=c; err=fb-fa; }
                   else if(jm<fc&&jm>fa){b=c;err=fb-fa;}
 
                   if(b-a<=10){
                        for(int i=0;i<int(b-a);i++){
                                fa=countyear(1900,int(a)+i);
                                fb=countyear(1900,int(a)+1+i);
                                c=int(a)+i;  
                                //cout<<fa<<" "<<jm<<" "<<fb<<" "<<endl;
                                if(fa<=jm&&jm<fb)break;
                                //i++;
                                }
                         err=0;       
                  }
           }          
return(int(c));
}

int bisnmonth(int ni,int nf,int nj,int iyear1)
{
     float a,b,jm,err=2,fa,fb,fc;
     a=float(ni); b=float(nf); jm=float(nj);
     float c;

     while(err>1){
                   fa=countmonth(iyear1,1,int(a)); 
                   fb=countmonth(iyear1,1,int(b));    
                   c=(a+b)/2;
                   fc=countmonth(iyear1,1,int(c));
                   if(jm==fb){c=b;err=0;}
                   else if(jm==fa){c=a;err=0;} 
                   else if(jm>fc&&jm<fb){a=c; err=fb-fa; }
                   else if(jm<fc&&jm>fa){b=c;err=fb-fa;}
 
                   if(b-a<=10){
                        for(int i=0;i<int(b-a);i++){
                                fa=countmonth(iyear1,1,int(a)+i);
                                fb=countmonth(iyear1,1,int(a)+1+i);
                                c=int(a)+i;  
                                //cout<<fa<<" "<<jm<<" "<<fb<<" "<<endl;
                                if(fa<=jm&&jm<fb)break;
                                //i++;
                                }
                         err=0;       
                  }
           }          
return(int(c));
}

int bisnday(int ni,int nf,int nj,int iyear1,int imonth1)
{
     float a,b,jm,err=2,fa,fb,fc;
     a=float(ni); b=float(nf); jm=float(nj);
     float c;
     
     fb=countday(iyear1,imonth1,1,int(b));    
     while(fb==-1){
         b=b-1;
         fb=countday(iyear1,imonth1,1,int(b));    
         //cout<<"El error puede resolverse en forma automatica"<<endl;
         }
        
     while(err>1){
                   fa=countday(iyear1,imonth1,1,int(a)); 
                   fb=countday(iyear1,imonth1,1,int(b));    
                   c=(a+b)/2;
                   fc=countday(iyear1,imonth1,1,int(c));
                   if(jm==fb){c=b;err=0;}
                   else if(jm==fa){c=a;err=0;} 
                   else if(jm>fc&&jm<fb){a=c; err=fb-fa; }
                   else if(jm<fc&&jm>fa){b=c;err=fb-fa;}
                   else if(jm==fc){err=0;}
                   
                   if(b-a<=10){
                        for(int i=0;i<int(b-a);i++){
                                fa=countday(iyear1,imonth1,1,int(a)+i);
                                fb=countday(iyear1,imonth1,1,int(a)+1+i);
                                c=int(a)+i;  
                                //cout<<fa<<" "<<jm<<" "<<fb<<" "<<endl;
                                if(fa<=jm&&jm<fb)break;
                                //i++;
                                }
                         err=0;       
                  }
           }          
return(int(c));
}

int bisnt(int jhym,int &year,int &month,int &day)
{
    //int year, month, day;
    int delta;
    //int iyear[201],leap[201];
    
    /*ifstream in("leapyear.txt");
    for(int i=0;i<201;i++)in>>iyear[i]>>leap[i];*/
    
    year=bisnyear(1900,2100,jhym);
    cout<<"year = "<<year<<endl;
    delta=jhym-countyear(1900,year);
    month=bisnmonth(1,12,delta,year);
    delta=delta-countmonth(year,1,month);
    day=bisnday(1,31,delta,year,month);
    delta=delta-countday(year,month,1,day);
    
    //year=iyear[year];
    //cout<<"year = "<<year<<"; month = "<<month<<"; day = "<<day<<endl;

return(delta);
} 


int bisn(int ni,int nf,float fun(float),int nj)
{
     float a,b,jm,err=2,fa,fb,fc;
     a=float(ni); b=float(nf); jm=float(nj);
     float c;

     while(err>1){
                   fa=fun(a); fb=fun(b);    
                   c=(a+b)/2;
                   fc=fun(c);
                   if(jm==fb){c=b;err=0;}
                   else if(jm==fa){c=a;err=0;} 
                   else if(jm>fc&&jm<fb){a=c; err=fb-fa; }
                   else if(jm<fc&&jm>fa){b=c;err=fb-fa;}
 
                   if(b-a<=10){
                        for(int i=0;i<int(b-a);i++){
                                fa=fun(int(a)+i);
                                fb=fun(int(a)+1+i);
                                c=int(a)+i;  
                                //cout<<fa<<" "<<jm<<" "<<fb<<" "<<endl;
                                if(fa<=jm&&jm<fb)break;
                                //i++;
                                }
                         err=0;       
                  }
           }          
return(int(c));
}

//hour varia entre 0 y 23
//min entre 0 y 59
//sec entre 0 y 59
float jhd(int hour,int min,int sec)
{
      float time;
      time=hour/3600+min/60+sec;
      return(time);
}    

void bisnhd(float jhd1,int &hour,int &min,int &sec)
{
       
     int time,i;
     
     for(hour=0;hour<24;hour++)
       if(hour<time&&time<hour+1)break;

     time=(time-hour)*60;  
       
     for(min=0;min<59;min)   
       if(min<time&&time<min+1)break;
       
     time=(time-min)*60;
     
     for(sec=0;sec<59;sec)   
       if(sec<time&&time<sec+1)break;

}
